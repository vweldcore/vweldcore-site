#!/data/data/com.termux/files/usr/bin/bash

BASE="$HOME/vweldcore-products/termux-crypto-monitor"

cd "$BASE"

LOG_FILE="$BASE/logs/runtime.log"

mkdir -p "$BASE/logs"

echo "[START] $(date)" >> "$LOG_FILE"

while true
do
    bash "$BASE/scan.sh" >> "$LOG_FILE" 2>&1

    echo "[DONE] $(date)" >> "$LOG_FILE"

    sleep 300
done

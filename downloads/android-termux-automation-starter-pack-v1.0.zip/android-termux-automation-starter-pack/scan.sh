#!/data/data/com.termux/files/usr/bin/bash

echo "[SCAN] $(date)"

declare -A RPCS

RPCS[polygon]="https://polygon-bor.publicnode.com"
RPCS[bsc]="https://bsc.publicnode.com"

for CHAIN in "${!RPCS[@]}"
do
    RPC="${RPCS[$CHAIN]}"

    echo "[CHAIN] $CHAIN"
    echo "[RPC] $RPC"

    RESPONSE=$(curl -s \
    --max-time 20 \
    -H "Content-Type: application/json" \
    -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' \
    "$RPC")

    if [ -z "$RESPONSE" ]; then
        echo "[FAIL] empty response"
    else
        echo "$RESPONSE"
    fi

    echo
done

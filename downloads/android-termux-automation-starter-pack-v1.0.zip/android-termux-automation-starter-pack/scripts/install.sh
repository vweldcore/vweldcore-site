#!/data/data/com.termux/files/usr/bin/bash

clear

echo "=================================="
echo "TERMUX CRYPTO MONITOR INSTALLER"
echo "=================================="

pkg update -y

pkg install curl jq termux-api -y

mkdir -p logs

chmod +x scan.sh
chmod +x daemon-v2.sh

mkdir -p ~/.termux/boot

cat > ~/.termux/boot/start-crypto-monitor.sh << BOOT
#!/data/data/com.termux/files/usr/bin/bash

termux-wake-lock

cd "\$HOME/vweldcore-products/termux-crypto-monitor"

pkill -f daemon-v2.sh 2>/dev/null || true

nohup bash daemon-v2.sh >/dev/null 2>&1 &
BOOT

chmod +x ~/.termux/boot/start-crypto-monitor.sh

pkill -f daemon-v2.sh 2>/dev/null || true

nohup bash daemon-v2.sh >/dev/null 2>&1 &

sleep 5

echo
echo "=================================="
echo "VERIFYING"
echo "=================================="

ps -ef | grep daemon-v2.sh | grep -v grep

echo
echo "=================================="
echo "LATEST LOGS"
echo "=================================="

tail -20 logs/runtime.log

echo
echo "=================================="
echo "INSTALL COMPLETE"
echo "=================================="
